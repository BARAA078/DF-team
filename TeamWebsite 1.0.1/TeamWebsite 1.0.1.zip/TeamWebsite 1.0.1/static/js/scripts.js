// فتح وإغلاق القائمة الجانبية
document.addEventListener('DOMContentLoaded', function () {
  const menuBtn = document.getElementById('menuBtn');
  const sideNav = document.getElementById('sideNav');
  const closeNav = document.getElementById('closeNav');
  const navOverlay = document.getElementById('navOverlay');

  if (menuBtn) menuBtn.onclick = () => {
    sideNav.classList.add('open');
    navOverlay.classList.add('open');
  };
  if (closeNav) closeNav.onclick = () => {
    sideNav.classList.remove('open');
    navOverlay.classList.remove('open');
  };
  if (navOverlay) navOverlay.onclick = () => {
    sideNav.classList.remove('open');
    navOverlay.classList.remove('open');
  };

  // زر الوضع الليلي/النهاري (قابل للتوسعة)
  document.getElementById('toggleTheme').onclick = function() {
    document.body.classList.toggle('light-theme');
    // يمكنك تحسين هذا الزر لاحقاً ليدعم تغيير الألوان فعلياً
  };
});